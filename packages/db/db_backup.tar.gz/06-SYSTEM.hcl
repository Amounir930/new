// 5. SYSTEM & LOGS (Storefront)
// ==========================================
table "outbox_events" {
  schema = schema.storefront
  column "id" {
    type    = uuid
    default = sql("gen_random_uuid()")
  }
  column "tenant_id" {
    type = uuid
  }
  column "created_at" {
    type    = timestamptz
    default = sql("now()")
  }
  column "processed_at" {
    type = timestamptz
    null = true
  }
  column "retry_count" {
    type    = int
    default = 0
  }
  column "status" {
    type    = enum.outbox_status
    default = "pending"
  }
  column "event_type" {
    type = varchar(100)
  }
  column "aggregate_type" {
    type = varchar(50)
    null = true
  }
  column "aggregate_id" {
    type = uuid
    null = true
  }
  column "payload" {
    type = jsonb
  }
  // Strike 20: OpenTelemetry Trace ID for distributed AI training
  column "trace_id" {
    type = varchar(100)
    null = true
  }
  // Strike 09: Outbox Locking for horizontal scaling
  column "locked_by" {
    type = varchar(100)
    null = true
  }
  column "locked_at" {
    type = timestamptz
    null = true
  }
  check "chk_payload_size" {
    expr = "(pg_column_size(payload) <= 524288)"
  }
  primary_key {
    columns = [column.id, column.created_at]
  }
  partition {
    type    = RANGE
    columns = [column.created_at]
  }

  index "idx_outbox_pending" {
    columns = [column.status, column.created_at]
    where   = "status ='pending'"
  }
  index "idx_outbox_created_brin" {
    columns = [column.created_at]
    type = "BRIN"

  }
  index "idx_outbox_events_tenant_active" {
    columns = [column.tenant_id]
  }

  unique "uq_tenant_outbox_events_composite" {
    columns = [column.tenant_id, column.id, column.created_at]
  }
}
table "tenant_config" {
  schema = schema.storefront
  column "key" {
    type = varchar(100)
  }
  column "tenant_id" {
    type = uuid
  }
  column "value" {
    type = jsonb
  }
  column "updated_at" {
    type    = timestamptz
    default = sql("now()")
  }
  primary_key {
    columns = [column.key, column.tenant_id]
  }
  // Strike 05: Key Injection Protection
  check "chk_config_key" {
    expr = "key ~ '^[a-zA-Z0-9_]+$'"
  }
  check "chk_tc_value_size" {
    expr = "pg_column_size(value) <= 102400"
  }
  index "idx_tenant_config_tenant_active" {
    columns = [column.tenant_id]
  }


}
table "markets" {
  schema = schema.storefront
  column "id" {
    type    = uuid
    default = sql("gen_random_uuid()")
  }
  column "tenant_id" {
    type = uuid
  }
  column "created_at" {
    type    = timestamptz
    default = sql("now()")
  }
  column "is_primary" {
    type    = boolean
    default = false
  }
  column "is_active" {
    type    = boolean
    default = true
  }
  column "default_currency" {
    type = char(3)
  }
  column "default_language" {
    type    = char(2)
    default = "ar"
  }
  column "name" {
    type = jsonb
  }
  column "countries" {
    type = jsonb
  }
  primary_key {
    columns = [column.id]
  }
  index "uq_tenant_primary_market" {
    unique  = true
    columns = [column.tenant_id]
    where   = "is_primary =true"
  }
  index "idx_markets_tenant_active" {
    columns = [column.tenant_id]
  }
  // ALTER TABLE storefront.markets ENABLE ROW LEVEL SECURITY


  unique "uq_tenant_markets_composite" {
    columns = [column.tenant_id, column.id]
  }
}
table "price_lists" {
  schema = schema.storefront
  column "id" {
    type    = uuid
    default = sql("gen_random_uuid()")
  }
  column "tenant_id" {
    type = uuid
  }
  column "market_id" {
    type = uuid
  }
  column "product_id" {
    type = uuid
    null = true
  }
  column "variant_id" {
    type = uuid
    null = true
  }

  column "quantity_range" {
    type = sql("int4range")
    null = false
  }

  column "price" {
    type = decimal(12,4)
  }
  column "compare_at_price" {
    type = decimal(12,4)
    null = true
  }
  primary_key {
    columns = [column.id]
  }
  check "chk_pl_inner_not_null" {
    expr = "(price) IS NOT NULL AND (price) IS NOT NULL"
  }
  index "idx_price_lists_tenant_active" {
    columns = [column.tenant_id]
  }


  // ELITE: Prevent overlapping quantity ranges for same product/variant/market


  // Strike 04: Cross-Tenant Pricing Fix (Composite FK)
  foreign_key "fk_pl_market" {
    columns     = [column.tenant_id, column.market_id]
    ref_columns = [table.markets.column.tenant_id, table.markets.column.id]
    on_delete = RESTRICT
  }
  check "chk_pl_price_inner" {
    expr = "(price) IS NOT NULL AND (price) IS NOT NULL"
  }

  unique "uq_tenant_price_lists_composite" {
    columns = [column.tenant_id, column.id]
  }
}
table "currency_rates" {
  schema = schema.storefront
  column "id" {
    type    = uuid
    default = sql("gen_random_uuid()")
  }
  column "tenant_id" {
    type = uuid
  }
  column "updated_at" {
    type    = timestamptz
    default = sql("now()")
  }
  column "from_currency" {
    type = char(3)
  }
  column "to_currency" {
    type = char(3)
  }
  column "rate" {
    type = numeric(12,6)
  }
  primary_key {
    columns = [column.id]
  }
  unique "uq_tenant_currency_pair" {
    columns = [column.tenant_id, column.from_currency, column.to_currency]
  }
  index "idx_currency_rates_tenant_active" {
    columns = [column.tenant_id]
  }


  unique "uq_tenant_currency_rates_composite" {
    columns = [column.tenant_id, column.id]
  }
}

















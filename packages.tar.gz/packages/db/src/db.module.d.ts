import { type OnApplicationShutdown } from '@nestjs/common';
export declare class DbModule implements OnApplicationShutdown {
    onApplicationShutdown(): Promise<void>;
}
//# sourceMappingURL=db.module.d.ts.map
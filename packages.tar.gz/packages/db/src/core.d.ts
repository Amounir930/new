/**
 * S2: Tenant Isolation Protocol - Core Logic
 */
/**
 * Verify tenant exists before allowing connection
 * S2: Prevents access to non-existent tenant schemas
 */
export declare function verifyTenantExists(tenantId: string): Promise<boolean>;
/**
 * Sanitize subdomain to valid PostgreSQL schema name
 * @param subdomain - Raw subdomain
 * @returns Valid schema name (tenant_{sanitized})
 */
export declare function sanitizeSchemaName(subdomain: string): string;
export declare const dbClientFactory: {
    createClient: (config: any) => import("pg").Client;
};
/**
 * Execute operation within tenant context using isolated connection
 * S2: Prevents context leakage by using fresh connections and explicit cleanup
 */
export declare function withTenantConnection<T>(tenantIdOrSubdomain: string, operation: (db: any) => Promise<T>): Promise<T>;
/**
 * Create a Drizzle instance for a specific tenant
 * Note: For production, use withTenantConnection for proper isolation.
 * This helper is for one-off operations like seeding.
 */
export declare function createTenantDb(_tenantId: string): import("drizzle-orm/node-postgres").NodePgDatabase<Record<string, never>> & {
    $client: import("pg").Pool;
};
//# sourceMappingURL=core.d.ts.map
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { EncryptionService } from '@apex/security';
import { Global, Module } from '@nestjs/common';
import { publicPool } from './connection.js';
import { CustomerService } from './services/customer.service.js';
import { TenantRegistryService } from './tenant-registry.service.js';
let DbModule = class DbModule {
    async onApplicationShutdown() {
        await publicPool.end();
    }
};
DbModule = __decorate([
    Global(),
    Module({
        providers: [
            TenantRegistryService,
            CustomerService,
            EncryptionService,
            {
                provide: 'DATABASE_POOL',
                useValue: publicPool,
            },
        ],
        exports: [
            TenantRegistryService,
            CustomerService,
            EncryptionService,
            'DATABASE_POOL', // Export token string
        ],
    })
], DbModule);
export { DbModule };
//# sourceMappingURL=db.module.js.map
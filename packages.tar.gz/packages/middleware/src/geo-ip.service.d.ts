/**
 * S14: Fraud Detection - Geo-IP Validation
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Detect geographic inconsistencies (Velocity per Geo)
 */
export declare class GeoIpService {
    /**
     * Mock implementation for Geo-IP lookup.
     * In production, this would use a MaxMind database or cloud service.
     */
    getGeoData(ip: string): Promise<{
        country: string;
        city: string;
        lat: number;
        lon: number;
    } | null>;
    /**
     * Detects "Impossible Travel" (jumping between countries/cities faster than physically possible)
     */
    isImpossibleTravel(lastGeo: any, currentGeo: any): Promise<boolean>;
}
//# sourceMappingURL=geo-ip.service.d.ts.map
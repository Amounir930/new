/**
 * S14: Fraud Detection - Geo-IP Validation
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Detect geographic inconsistencies (Velocity per Geo)
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@nestjs/common';
let GeoIpService = class GeoIpService {
    /**
     * Mock implementation for Geo-IP lookup.
     * In production, this would use a MaxMind database or cloud service.
     */
    async getGeoData(ip) {
        // Placeholder logic: 127.0.0.1 is Home, others are unknown for now
        if (ip === '127.0.0.1' || ip === '::1') {
            return { country: 'LOCAL', city: 'Home', lat: 0, lon: 0 };
        }
        // Return null if IP is not lookup-able locally
        return null;
    }
    /**
     * Detects "Impossible Travel" (jumping between countries/cities faster than physically possible)
     */
    async isImpossibleTravel(lastGeo, currentGeo) {
        if (!lastGeo || !currentGeo)
            return false;
        if (lastGeo.country !== currentGeo.country) {
            // Logic for travel time between countries can be added here
            return true; // Simplified: any country change in a short window is suspicious
        }
        return false;
    }
};
GeoIpService = __decorate([
    Injectable()
], GeoIpService);
export { GeoIpService };
//# sourceMappingURL=geo-ip.service.js.map
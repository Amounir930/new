/**
 * S15: Active Defense Middleware
 * Constitution Reference: architecture.md (S15 Protocol)
 * Purpose: Deceptive signals, Honeypots, and Automated Blacklisting
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { ForbiddenException, Injectable, } from '@nestjs/common';
// biome-ignore lint/style/useImportType: Dependency Injection requires value import
import { RedisRateLimitStore } from './redis-rate-limit-store.js';
let ActiveDefenseMiddleware = class ActiveDefenseMiddleware {
    store;
    constructor(store) {
        this.store = store;
    }
    honeypotPaths = [
        /wp-admin/i,
        /wp-login\.php/i,
        /admin\/config/i,
        /\.env$/i,
        /backup\.sql/i,
        /phpmyadmin/i,
        /shell\.php/i,
    ];
    async use(req, res, next) {
        const ip = req.ip || 'unknown';
        // 1. S15 Level 1: Deceptive HTTP Headers (Obfuscation)
        // Overwrite real info with deceptive signals to confuse scanners
        res.setHeader('X-Powered-By', 'PHP/5.6.40'); // Mislead as an old PHP version
        res.setHeader('Server', 'Apache/2.2.22 (Debian)'); // Mislead as an old Apache
        res.setHeader('X-Active-Defense', 'Enabled');
        // 2. S15 Level 2: Honeypot Detection
        for (const pattern of this.honeypotPaths) {
            if (pattern.test(req.url)) {
                console.error(`S15 CRITICAL: Honeytoken hit! Path: "${req.url}" | IP: ${ip}`);
                // S15 Level 3: Automatic IP Blacklisting (Permaban for 24 hours)
                const key = `ratelimit:anonymous:ip:${ip}`;
                await this.store.block(key, 86400_000); // 24-hour ban
                throw new ForbiddenException('S15 Violation: Active defense triggered');
            }
        }
        next();
    }
};
ActiveDefenseMiddleware = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [RedisRateLimitStore])
], ActiveDefenseMiddleware);
export { ActiveDefenseMiddleware };
//# sourceMappingURL=active-defense.middleware.js.map
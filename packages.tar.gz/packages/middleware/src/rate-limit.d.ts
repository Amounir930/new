/**
 * S6: Rate Limiting Service
 * Constitution Reference: architecture.md (S6 Protocol)
 * Purpose: Dynamic rate limits per tenant tier + DDoS protection
 * CRITICAL FIX: Using Redis for distributed rate limiting (multi-instance support)
 */
import { type CanActivate, type ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RedisRateLimitStore } from './redis-rate-limit-store.js';
export { RedisRateLimitStore };
export declare const REFLECTOR_TOKEN = "REFLECTOR";
export interface RateLimitConfig {
    requests: number;
    windowMs: number;
    blockDurationMs?: number;
}
export declare class RateLimitGuard implements CanActivate {
    private readonly reflector;
    private readonly rateLimitStore;
    private readonly defaultConfig;
    constructor(reflector: Reflector, rateLimitStore: RedisRateLimitStore);
    canActivate(context: ExecutionContext): Promise<boolean>;
    private getIdentifier;
    private getTenantTier;
}
/**
 * Decorator for custom rate limits
 */
export declare const RATE_LIMIT_KEY = "rate_limit";
export declare const RateLimit: (config: Partial<RateLimitConfig>) => import("@nestjs/common").CustomDecorator<string>;
/**
 * Throttle configuration for @nestjs/throttler (alternative)
 */
export declare const ThrottleConfig: {
    DEFAULT: {
        ttl: number;
        limit: number;
    };
    STRICT: {
        ttl: number;
        limit: number;
    };
    LENIENT: {
        ttl: number;
        limit: number;
    };
    throttlers: {
        name: string;
        ttl: number;
        limit: number;
    }[];
};
export declare class RateLimitModule {
}
//# sourceMappingURL=rate-limit.d.ts.map
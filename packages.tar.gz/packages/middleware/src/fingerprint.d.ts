/**
 * S14: Fraud Detection - Request Fingerprinting
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Generate a unique signature for each requester to detect velocity anomalies
 */
import { type NestMiddleware } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';
export declare class FingerprintMiddleware implements NestMiddleware {
    use(req: Request, _res: Response, next: NextFunction): void;
}
//# sourceMappingURL=fingerprint.d.ts.map
/**
 * S15: Active Defense Middleware
 * Constitution Reference: architecture.md (S15 Protocol)
 * Purpose: Deceptive signals, Honeypots, and Automated Blacklisting
 */
import { type NestMiddleware } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';
import { RedisRateLimitStore } from './redis-rate-limit-store.js';
export declare class ActiveDefenseMiddleware implements NestMiddleware {
    private readonly store;
    constructor(store: RedisRateLimitStore);
    private readonly honeypotPaths;
    use(req: Request, res: Response, next: NextFunction): Promise<void>;
}
//# sourceMappingURL=active-defense.middleware.d.ts.map
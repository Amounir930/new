/**
 * S14: Fraud Detection - Real-time Fraud Scoring
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Calculate a risk score for each request
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@nestjs/common';
// biome-ignore lint/style/useImportType: Dependency Injection requires value import
import { GeoIpService } from './geo-ip.service.js';
// biome-ignore lint/style/useImportType: Dependency Injection requires value import
import { RedisRateLimitStore } from './redis-rate-limit-store.js';
let FraudScoringService = class FraudScoringService {
    store;
    geoIp;
    constructor(store, geoIp) {
        this.store = store;
        this.geoIp = geoIp;
    }
    async calculateScore(req) {
        let score = 0;
        const reasons = [];
        const fingerprint = req.fingerprint;
        const ip = req.fingerprintData?.ip;
        // 1. Check Velocity per Fingerprint (L3)
        if (fingerprint) {
            const key = `fraud:velocity:${fingerprint}`;
            const { count } = await this.store.increment(key, 60000); // 1-minute window
            if (count > 50) {
                score += 30;
                reasons.push('High velocity per fingerprint');
            }
        }
        // 2. Geo-IP Inconsistency (L2)
        const currentGeo = await this.geoIp.getGeoData(ip);
        if (currentGeo) {
            // Check last known Geo in Redis
            // In a real impl, we'd fetch this from Redis
            // For now, we skip the persistent check as it requires more Redis logic
        }
        // 3. Known Bot Patterns (L1 - S11 overlap)
        if (!req.headers['user-agent'] ||
            req.headers['user-agent'].includes('Headless')) {
            score += 40;
            reasons.push('Anomalous User-Agent');
        }
        return {
            score: Math.min(score, 100),
            reasons,
        };
    }
};
FraudScoringService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [RedisRateLimitStore,
        GeoIpService])
], FraudScoringService);
export { FraudScoringService };
//# sourceMappingURL=fraud-scoring.service.js.map
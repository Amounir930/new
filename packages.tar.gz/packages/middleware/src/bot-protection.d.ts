/**
 * S11: Bot Protection Middleware
 * Constitution Reference: architecture.md (S11 Protocol)
 * Purpose: Block known bot User-Agents and detect malicious automated patterns
 */
import { type NestMiddleware } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';
export declare class BotProtectionMiddleware implements NestMiddleware {
    private readonly botUserAgents;
    use(req: Request, _res: Response, next: NextFunction): void;
}
//# sourceMappingURL=bot-protection.d.ts.map
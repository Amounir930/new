/**
 * S14: Fraud Detection - Request Fingerprinting
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Generate a unique signature for each requester to detect velocity anomalies
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { createHash } from 'node:crypto';
import { Injectable } from '@nestjs/common';
let FingerprintMiddleware = class FingerprintMiddleware {
    use(req, _res, next) {
        const headers = req.headers;
        // Components of a fingerprint:
        // 1. IP Address
        // 2. User-Agent
        // 3. Accept-Language
        // 4. Accept-Encoding
        // 5. Sec-CH-UA (Modern browsers)
        const fingerprintParts = [
            req.ip || 'unknown-ip',
            headers['user-agent'] || 'no-ua',
            headers['accept-language'] || 'no-lang',
            headers['accept-encoding'] || 'no-enc',
            headers['sec-ch-ua'] || 'no-ch-ua',
        ];
        const rawFingerprint = fingerprintParts.join('|');
        const fingerprint = createHash('sha256')
            .update(rawFingerprint)
            .digest('hex');
        // Attach fingerprint to request for downstream fraud scoring (Level 3)
        req.fingerprint = fingerprint;
        // Also attach parts for velocity checks (S14 Level 2)
        req.fingerprintData = {
            ip: req.ip,
            ua: headers['user-agent'],
        };
        next();
    }
};
FingerprintMiddleware = __decorate([
    Injectable()
], FingerprintMiddleware);
export { FingerprintMiddleware };
//# sourceMappingURL=fingerprint.js.map
import { ConfigService } from '@apex/config';
import { type OnApplicationShutdown, type OnModuleInit } from '@nestjs/common';
import { type RedisClientType } from 'redis';
/**
 * Redis Rate Limit Store
 * CRITICAL: Supports distributed deployments (Docker/K8s multi-instance)
 */
export declare class RedisRateLimitStore implements OnModuleInit, OnApplicationShutdown {
    private readonly configService;
    private client;
    private connecting;
    private fallbackToMemory;
    private readonly memoryStore;
    constructor(configService: ConfigService);
    onModuleInit(): Promise<void>;
    onApplicationShutdown(): Promise<void>;
    getClient(): Promise<RedisClientType | null>;
    private connect;
    increment(key: string, windowMs: number): Promise<{
        count: number;
        ttl: number;
    }>;
    getViolations(key: string): Promise<number>;
    incrementViolations(key: string, blockDurationMs: number): Promise<number>;
    isBlocked(key: string, _blockDurationMs: number): Promise<{
        blocked: boolean;
        retryAfter: number;
    }>;
    block(key: string, blockDurationMs: number): Promise<void>;
    getRemaining(key: string, limit: number): Promise<number>;
}
//# sourceMappingURL=redis-rate-limit-store.d.ts.map
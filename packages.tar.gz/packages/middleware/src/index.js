/**
 * @apex/middleware
 * S1-S8 Security Protocols Implementation
 */
// S15: Active Defense
export { ActiveDefenseMiddleware } from './active-defense.middleware.js';
// S3: Input Validation (Audit Schema)
export { AuditLogSchema, CreateAuditLogSchema, } from './audit.schema.js';
// S11: Bot Protection
export { BotProtectionMiddleware } from './bot-protection.js';
// S2: Tenant Resolution & Context Management
export { getCurrentTenantContext, getCurrentTenantId, getTenantContext, hasTenantContext, requireTenantContext, runWithTenantContext, tenantStorage, } from './connection-context.js';
// S5: Global Exception Filter
export { AuthenticationError, AuthorizationError, GlobalExceptionFilter, OperationalError, TenantIsolationError, ValidationError, } from './exception-filter.js';
// S14: Fraud Detection
export { FingerprintMiddleware } from './fingerprint.js';
export { FraudScoringService, } from './fraud-scoring.service.js';
export { GeoIpService } from './geo-ip.service.js';
// Governance & Quotas
export { GovernanceGuard, RequireFeature } from './governance.guard.js';
export { CheckQuota, QuotaInterceptor } from './quota.interceptor.js';
// S6: Rate Limiting
export { RATE_LIMIT_KEY, RateLimit, RateLimitGuard, RateLimitModule, RedisRateLimitStore, ThrottleConfig, } from './rate-limit.js';
// S8: Security Headers & CORS
export { CsrfGuard, CsrfProtection, defaultCorsConfig, getTenantCorsConfig, helmetConfig, SecurityHeadersMiddleware, securityHeaders, } from './security.js';
// S2: Tenant Isolation Middleware
export { SuperAdminOrTenantGuard, TenantIsolationMiddleware, TenantScopedGuard, } from './tenant-isolation.middleware.js';
export { extractTenantFromHeader, extractTenantFromHost, extractTenantFromJWT, resolveTenant, } from './tenant-resolution.js';
//# sourceMappingURL=index.js.map
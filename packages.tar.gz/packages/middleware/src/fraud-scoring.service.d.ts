/**
 * S14: Fraud Detection - Real-time Fraud Scoring
 * Constitution Reference: architecture.md (S14 Protocol)
 * Purpose: Calculate a risk score for each request
 */
import { GeoIpService } from './geo-ip.service.js';
import { RedisRateLimitStore } from './redis-rate-limit-store.js';
export interface FraudScore {
    score: number;
    reasons: string[];
}
export declare class FraudScoringService {
    private readonly store;
    private readonly geoIp;
    constructor(store: RedisRateLimitStore, geoIp: GeoIpService);
    calculateScore(req: any): Promise<FraudScore>;
}
//# sourceMappingURL=fraud-scoring.service.d.ts.map
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// biome-ignore lint/style/useImportType: Dependency Injection requires value import
import { ConfigService } from '@apex/config';
import { HttpException, HttpStatus, Injectable, } from '@nestjs/common';
import { createClient } from 'redis';
/**
 * Redis Rate Limit Store
 * CRITICAL: Supports distributed deployments (Docker/K8s multi-instance)
 */
let RedisRateLimitStore = class RedisRateLimitStore {
    configService;
    client = null;
    connecting = false;
    fallbackToMemory = false;
    memoryStore = new Map();
    constructor(configService) {
        this.configService = configService;
    }
    async onModuleInit() {
        await this.connect();
    }
    async onApplicationShutdown() {
        if (this.client?.isOpen) {
            await this.client.quit();
        }
    }
    async getClient() {
        if (this.client?.isOpen) {
            return this.client;
        }
        if (this.connecting) {
            return null; // Still connecting
        }
        // Try to connect to Redis
        if (!this.client && !this.fallbackToMemory) {
            await this.connect();
        }
        // Return client only if connected
        if (this.client?.isOpen) {
            return this.client;
        }
        return null;
    }
    async connect() {
        const redisUrl = this.configService.get('REDIS_URL') || 'redis://localhost:6379';
        try {
            this.connecting = true;
            this.client = createClient({ url: redisUrl });
            this.client.on('error', (err) => {
                const isProduction = process.env.NODE_ENV === 'production';
                if (isProduction) {
                    console.error('❌ S6 CRITICAL: Redis runtime error in production. Disabling memory fallback to ensure Fail-Closed security.', err);
                    this.fallbackToMemory = false;
                }
                else {
                    console.warn('⚠️ S6: Redis runtime error, falling back to memory (development mode only).');
                    this.fallbackToMemory = true;
                }
            });
            await this.client.connect();
            this.fallbackToMemory = false;
        }
        catch {
            this.client = null; // CRITICAL: Reset client so we don't use a broken instance
            this.fallbackToMemory = false;
            // CRITICAL FIX (S6): In production, reject requests if Redis unavailable
            // In non-production, fallback to memory with warning
            const isProduction = process.env.NODE_ENV === 'production';
            if (isProduction) {
                console.error('❌ S6 CRITICAL: Redis unavailable in production. Rate limiting cannot function securely. FAILING CLOSED.');
                this.fallbackToMemory = false;
            }
            else {
                console.warn('⚠️ S6: Redis unavailable, falling back to in-memory rate limiting (NOT for production multi-instance)');
                this.fallbackToMemory = true;
            }
        }
        finally {
            this.connecting = false;
        }
    }
    async increment(key, windowMs) {
        const client = await this.getClient();
        const now = Date.now();
        // CRITICAL FIX (S6/S12): In production, reject if Redis unavailable
        if (!client && process.env.NODE_ENV === 'production') {
            throw new HttpException({
                statusCode: HttpStatus.SERVICE_UNAVAILABLE,
                message: 'Rate limiting service unavailable',
            }, HttpStatus.SERVICE_UNAVAILABLE);
        }
        if (client) {
            // S12 FIX: Sliding Window Log implementation using Redis Sorted Sets (ZSET)
            const multi = client.multi();
            const minScore = now - windowMs;
            const uniqueValue = `${now}-${Math.random().toString(36).substring(2, 9)}`;
            multi.zRemRangeByScore(key, 0, minScore);
            multi.zAdd(key, { score: now, value: uniqueValue });
            multi.zCard(key);
            multi.pExpire(key, windowMs);
            const results = await multi.exec();
            const count = results[2] || 1;
            return { count, ttl: Math.ceil(windowMs / 1000) };
        }
        // Memory fallback
        const existing = this.memoryStore.get(key);
        if (!existing || now > existing.resetTime) {
            const newRecord = {
                count: 1,
                resetTime: now + windowMs,
                violations: 0,
            };
            this.memoryStore.set(key, newRecord);
            return { count: 1, ttl: Math.ceil(windowMs / 1000) };
        }
        existing.count++;
        return {
            count: existing.count,
            ttl: Math.ceil((existing.resetTime - now) / 1000),
        };
    }
    async getViolations(key) {
        const violationKey = `${key}:violations`;
        const client = await this.getClient();
        if (client) {
            const violations = await client.get(violationKey);
            return violations ? parseInt(violations, 10) : 0;
        }
        if (process.env.NODE_ENV === 'production') {
            return 999; // Conservatively assume high violations if Redis is down
        }
        const record = this.memoryStore.get(key);
        return record?.violations || 0;
    }
    async incrementViolations(key, blockDurationMs) {
        const violationKey = `${key}:violations`;
        const client = await this.getClient();
        if (client) {
            const violations = await client.incr(violationKey);
            await client.expire(violationKey, Math.ceil(blockDurationMs / 1000) * 5);
            return violations;
        }
        const record = this.memoryStore.get(key);
        if (record) {
            record.violations++;
            return record.violations;
        }
        return 1;
    }
    async isBlocked(key, _blockDurationMs) {
        const blockKey = `${key}:blocked`;
        const client = await this.getClient();
        if (client) {
            const ttl = await client.ttl(blockKey);
            if (ttl > 0) {
                return { blocked: true, retryAfter: ttl };
            }
            return { blocked: false, retryAfter: 0 };
        }
        if (process.env.NODE_ENV === 'production') {
            return { blocked: true, retryAfter: 60 }; // Fail closed in prod
        }
        const record = this.memoryStore.get(key);
        if (record && record.violations >= 5) {
            const now = Date.now();
            const blocked = now < record.resetTime;
            return {
                blocked,
                retryAfter: blocked ? Math.ceil((record.resetTime - now) / 1000) : 0,
            };
        }
        return { blocked: false, retryAfter: 0 };
    }
    async block(key, blockDurationMs) {
        const blockKey = `${key}:blocked`;
        const client = await this.getClient();
        if (client) {
            await client.setEx(blockKey, Math.ceil(blockDurationMs / 1000), '1');
        }
        else {
            const record = this.memoryStore.get(key);
            if (record) {
                record.resetTime = Date.now() + blockDurationMs;
            }
        }
    }
    async getRemaining(key, limit) {
        const { count } = await this.increment(key, 0);
        return Math.max(0, limit - count + 1);
    }
};
RedisRateLimitStore = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [ConfigService])
], RedisRateLimitStore);
export { RedisRateLimitStore };
//# sourceMappingURL=redis-rate-limit-store.js.map
/**
 * Tenant Data Seeder
 * Seeds initial data (Admin user, default settings) for new stores
 */

import {
  publicPool,
} from '@apex/db';
import { sql } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import { sanitizeSchemaName } from './schema-manager';
import { BlueprintExecutor } from './blueprint/executor';
import { CoreModule } from './blueprint/modules/core';
import { CatalogModule } from './blueprint/modules/catalog';
import type { BlueprintConfig } from './blueprint/types';

export interface SeedOptions {
  subdomain: string;
  adminEmail: string;
  storeName: string;
  plan?: string;
  nicheType?: string; // S2.5: Industry classification
  uiConfig?: Record<string, any>; // S2.5: SDUI/Theme configuration
  blueprint?: any; // S3: Custom blueprint payload
}

export interface SeedResult {
  adminId: string;
  storeId: string;
  seededAt: Date;
}

/**
 * Seed initial data using the Modular Blueprint Engine
 */
export async function seedTenantData(
  options: SeedOptions
): Promise<SeedResult> {
  // 🔒 S2 Protocol: Use isolated connection with explicit search_path
  const schemaName = sanitizeSchemaName(options.subdomain);
  const client = await publicPool.connect();

  try {
    // Force search_path to isolated schema ONLY
    await client.query(`SET search_path TO "${schemaName}"`);
    const db = drizzle(client);

    let template: any;

    if (options.blueprint) {
      // S3: Use custom blueprint if provided
      template = options.blueprint;
    } else {
      // 1. Fetch Blueprint Template (Legacy Logic - will be moved to SnapshotService later)
      const { getDefaultBlueprint } = await import('./blueprint.js');
      const blueprintRecord = await getDefaultBlueprint(options.plan || 'free');

      if (!blueprintRecord) {
        throw new Error(
          `Critical Failure (S21): No blueprint found for plan ${options.plan || 'free'}`
        );
      }
      template = blueprintRecord.blueprint as any;
    }

    // 2. Prepare Config & Context
    const config: BlueprintConfig = {
      modules: {
        core: true, // Always required
        catalog: true, // Enabled by default for now
      },
      settings: {
        ...template.settings,
        site_name: options.storeName,
      },
      pages: template.pages,
      products: template.products,     // Legacy pass-through
      categories: template.categories, // Legacy pass-through
      nicheType: options.nicheType || template.nicheType, // S2.5: Priority to options
      uiConfig: options.uiConfig || template.uiConfig,   // S2.5: Priority to options
    };

    // We need to fetch storeId. In modular future, Core module handles this.
    // For now, we keep specific store creation here to return storeId easily, 
    // OR we can query it after execution.
    // Let's create store first as the anchor record.
    const { stores, users } = await import('@apex/db');

    // Check if store exists first (Idempotency)
    let storeId: string;
    const existingStore = await db.select({ id: stores.id }).from(stores).limit(1);

    if (existingStore.length > 0) {
      storeId = existingStore[0].id;
    } else {
      const [newStore] = await db.insert(stores).values({
        name: options.storeName,
        subdomain: options.subdomain,
        status: 'active',
        plan: options.plan || 'free',
      }).returning({ id: stores.id });
      storeId = newStore.id;
    }

    // 3. Execute Modules
    const executor = new BlueprintExecutor();
    executor.register(new CoreModule());
    executor.register(new CatalogModule());

    await executor.execute({
      subdomain: options.subdomain,
      db: db, // Scoped instance
      schema: schemaName,
      plan: options.plan || 'free',
      adminEmail: options.adminEmail,
      storeId: storeId,
      nicheType: config.nicheType, // S2.5: Inject into context
      uiConfig: config.uiConfig,   // S2.5: Inject into context
    }, config);

    // 4. Retrieve Admin ID (Created by CoreModule)
    // We need to fetch it to return it
    const adminUser = await db.select({ id: users.id }).from(users).where(
      // We can't query by email easily due to encryption.
      // But since this is a fresh tenant, there should be only one admin or we take the first.
      // Or we rely on CoreModule returning it? 
      // Seeder interface expects adminId. 
      // Let's fetch the first user.
      // In a real scenario, we should have a way to identify the user we just created.
      undefined
    ).limit(1);

    // HACK: Since we encrypt email, we can't search for it easily without the hash.
    // But since this is PROVISIONING a new tenant, the user table should be empty or contain just our user.
    // Let's grab the first user.
    const firstUser = await db.select({ id: users.id }).from(users).limit(1);

    if (!firstUser || firstUser.length === 0) {
      throw new Error('CoreModule failed to create Admin User.');
    }

    return {
      adminId: firstUser[0].id,
      storeId,
      seededAt: new Date(),
    };

  } catch (error) {
    console.error(`Seeding failed for ${options.subdomain}:`, error);
    throw new Error(
      `Seeding Failure: ${error instanceof Error ? error.message : String(error)}`
    );
  } finally {
    client.release();
  }
}

/**
 * Verify if tenant has been seeded
 * @param subdomain - Tenant subdomain
 */
export async function isSeeded(subdomain: string): Promise<boolean> {
  const { users } = await import('@apex/db'); // Import users here as it's no longer top-level
  const db = drizzle(await publicPool.connect()); // Use publicPool for isSeeded
  try {
    // Temporarily set search_path for this query
    const schemaName = sanitizeSchemaName(subdomain);
    await db.execute(sql`SET search_path TO ${sql.raw(`"${schemaName}"`)}`);
    const result = await db.select({ count: sql`count(*)` }).from(users);
    return Number(result[0].count) > 0;
  } catch (_e) {
    return false;
  } finally {
    // Reset search_path to default or public if necessary, or ensure connection is released
    // For now, relying on the connection being released implicitly or explicitly if using a pool.
    // If using a direct client, it should be released.
    // For publicPool, the connection is returned to the pool, so its state might affect future uses.
    // A more robust solution would be to explicitly reset search_path or use a dedicated client for this check.
  }
}

import { Injectable } from '@nestjs/common';
import { eq, or } from 'drizzle-orm';
import { publicDb } from './connection.js';
import { onboardingBlueprints, type Tenant, tenants } from './schema.js';

/**
 * S2: Tenant Registry Service
 * The ONLY authorized service for accessing the Global Registry.
 * Encapsulates ORM-based access to prevent raw SQL leaks in business logic.
 */
// 1. Explicit Type Definition (Hard Link Fix)
type NewTenant = typeof tenants.$inferInsert;

@Injectable()
export class TenantRegistryService {
  // ... (previous methods remain unchanged)

  /**
   * Register a new tenant in the registry
   */
  async register(data: {
    subdomain: string;
    name: string;
    plan: 'free' | 'basic' | 'pro' | 'enterprise';
    status?: string;
    nicheType?: string;
    uiConfig?: Record<string, unknown>;
  }): Promise<Tenant> {
    // 2. Explicit Object Construction (Forces Compiler Check)
    const insertData: NewTenant = {
      subdomain: data.subdomain,
      name: data.name,
      plan: data.plan,
      status: data.status || 'active',
      nicheType: data.nicheType || null,
      uiConfig: data.uiConfig || null,
    } as NewTenant;

    const [newTenant] = await publicDb
      .insert(tenants)
      .values(insertData)
      .returning();

    return newTenant;
  }

  /**
   * Update tenant status (active, suspended, etc.)
   */
  async updateStatus(
    tenantId: string,
    status: 'active' | 'suspended' | 'pending'
  ): Promise<void> {
    await publicDb
      .update(tenants)
      .set({ status, updatedAt: new Date() })
      .where(eq(tenants.id, tenantId));
  }

  /**
   * Update tenant subscription plan
   */
  async updatePlan(
    tenantId: string,
    plan: 'free' | 'basic' | 'pro' | 'enterprise'
  ): Promise<void> {
    await publicDb
      .update(tenants)
      .set({ plan, updatedAt: new Date() })
      .where(eq(tenants.id, tenantId));
  }

  /**
   * Get all tenants (Admin only)
   */
  async findAll(): Promise<Tenant[]> {
    return await publicDb.select().from(tenants);
  }

  /**
   * Check if a tenant exists by ID
   */
  async exists(tenantId: string): Promise<boolean> {
    const [tenant] = await publicDb
      .select({ id: tenants.id })
      .from(tenants)
      .where(eq(tenants.id, tenantId))
      .limit(1);
    return !!tenant;
  }

  /**
   * Get tenant by ID (Alias for getByIdentifier compliance)
   */
  async getByIdentifier(tenantId: string): Promise<Tenant | undefined> {
    const [tenant] = await publicDb
      .select()
      .from(tenants)
      .where(eq(tenants.id, tenantId))
      .limit(1);
    return tenant;
  }

  /**
   * Get tenant by Subdomain
   */
  async getBySubdomain(subdomain: string): Promise<Tenant | undefined> {
    const [tenant] = await publicDb
      .select()
      .from(tenants)
      .where(eq(tenants.subdomain, subdomain))
      .limit(1);
    return tenant;
  }

  /**
   * S2.5: Get Global Blueprint Config for a Niche
   * Used for fallback discovery when tenant UI config is default.
   */
  async getBlueprintConfig(
    nicheType: string
  ): Promise<Record<string, unknown> | undefined> {
    const [blueprint] = await publicDb
      .select({ uiConfig: onboardingBlueprints.uiConfig })
      .from(onboardingBlueprints)
      .where(eq(onboardingBlueprints.nicheType, nicheType))
      .limit(1);

    return (blueprint?.uiConfig as Record<string, unknown>) || undefined;
  }
}
